class Administrator(private val authorizationData: AuthorizationData,
                    private var money: Int) :
    GeneralUser(authorizationData, money) {
}