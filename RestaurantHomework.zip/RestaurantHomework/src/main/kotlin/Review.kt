import kotlinx.serialization.Serializable

@Serializable
class Review(val score: Int, private val comment: String) {
    fun printReview() {
        println("Оценка: $score")
        println(comment)
    }
}