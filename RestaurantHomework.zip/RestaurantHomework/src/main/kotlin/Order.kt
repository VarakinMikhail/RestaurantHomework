import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlin.concurrent.thread

@Serializable
class Order {
    var all: MutableList<Dish> = mutableListOf()
    private var ready: MutableList<Pair<Dish, Int>> = mutableListOf()
    private var cooking: MutableList<Pair<Dish, Int>> = mutableListOf()
    private var canceled = false
    private var flag = 0
    var reviewed = false

    fun add(pair: Pair<Dish, Int>) {
        thread {
            pair.first.count -= pair.second
            cooking.add(pair)
            Thread.sleep(pair.first.cookingTime.toLong() * 1000)
            cooking.remove(pair)
            flag = 1
            Thread.sleep(100)
            ready.add(pair)
            flag = 0
        }
    }

    fun cancel(user: GeneralUser) {
        val cookingNow: MutableList<Pair<Dish, Int>> = mutableListOf()
        cookingNow.addAll(cooking)
        if (ready.isEmpty() && flag == 0 && !canceled) {
            for (pair in cookingNow) {
                user.back(pair.first, pair.second)
                pair.first.count += pair.second
            }
            println("Деньги за заказ возвращены на ваш счёт")
            canceled = true
        }
        else if (canceled){
            println("Заказ уже отменён, деньги возвращены на ваш счет. " +
                    "Еще раз отменить уже отмененный заказ нельзя")
        }
        else {
            println("Некоторые блюда в заказе уже готовы, поэтому отменить заказ нельзя")
        }
    }

    fun isEmpty() : Boolean {
        return ready.isEmpty() && cooking.isEmpty() && (flag == 0)
    }
}