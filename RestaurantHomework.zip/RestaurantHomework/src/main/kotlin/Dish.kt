import kotlinx.serialization.Serializable

@Serializable
class Dish(
    var cookingTime: Int,
    var count: Int,
    var price: Int,
    var dishName: String,
    var dishDescription: String) {
    private var averageScore: Double = 0.0
    private var reviewCount: Int = 0
    private var reviews: MutableList<Review> = mutableListOf()

    fun addReview(review: Review) {
        reviews.add(review)
        reviewCount += 1
        averageScore = averageScore / reviewCount * (reviewCount - 1) + review.score / reviewCount
    }

    fun printDish() {
        print("$dishName\t$price руб.\t")
        if (averageScore > 0){
            println(averageScore)
        }
        else{
            println()
        }
        println("Доступно $count шт. для заказа")
        println("Приготовление занимает $cookingTime секунд")
        println(dishDescription)
    }

    fun printReviews() {
        for (review in reviews) {
            review.printReview()
            println()
        }
    }
}