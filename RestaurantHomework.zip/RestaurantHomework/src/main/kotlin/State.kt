import kotlinx.serialization.Serializable
import java.lang.Exception

enum class States {
    HELLO,              // Начало работы программы
    REGISTER,           // Регистрация
    AUTHORIZATION,      // Авторизация
    SELECTION,          // Состояние сразу после авторизации
    ADMINSELECTION,
    ORDERING,           // Заказ блюд, просмотр меню и отзывов
    ORDERED,
    ADMINEDITING,       // Редактировать меню и блюда (на выбор)
    ADMINEDITMENU,      // Редактировать меню
    ADMINEDITDISH,      // Редактировать блюдо
    CANCELING,          // Отмена заказа
    REVIEW              // Написание отзыва
}

@Serializable
class State(private val authorizationSystem: AuthorizationSystem,
            private var menu: Menu) {
    private val startState: List<String> = listOf(
        "Здравствуйте! Войдите или зарегистрируйтесь:\n",
        "",
        "",
        "Что пожелаете?\n",
        "Что пожелаете?\n",
        "Выберите блюдо, чтобы добавить его в заказ или прочитать отзывы. " +
                "После выбора блюдо будет оплачено и начнётся его приготовление,\n" +
                "а вы сможете добавлять в заказ другие блюда. " +
                "После приготовления первого блюда из заказа, отменить заказ уже не получится\n",
        "Заказ завершён! Вы хотите отменить заказ или оценить блюда?\n",
        "Вы хотите отредактировать блюдо, или добавить блюдо в меню?\n",
        "Введите данные блюда, которое нужно добавить в меню\n",
        "Выберите блюдо, которое нужно отредактировать\n",
        "Вы хотите отменить заказ?\n",
        "Выберите блюдо, на которое хотите написать отзыв:\n")

    private val choicesStates: List<String> = listOf(
        "1. Войти\n" +
                "2. Зарегистрироваться\n" +
                "3. Выйти\n",
        "",
        "",
        "1. Сделать заказ\n",
        "1. Сделать заказ\n" +
                "2. Отредактировать меню\n",
        "",
        "1. Отменить заказ\n" +
                "2. Оценить блюдо\n",
        "1. Добавить блюдо в меню\n" +
                "2. Отредактировать блюдо\n",
        "",
        "",
        "1. Да, отменить заказ\n",
        ""
    )
    var current: States = States.HELLO
    var currentUser = GeneralUser(AuthorizationData("", ".", false), 0)
    private fun switchState(states: States) {
        current = states
        print(startState[current.ordinal])
        if (current != States.HELLO && current != States.REGISTER &&
            current != States.AUTHORIZATION && current != States.ORDERING &&
            current != States.ADMINEDITMENU && current != States.REVIEW){
            println("0. Вернуться назад")
        }
        print(choicesStates[current.ordinal])
    }

    fun hello() {
        while (true){
            switchState(States.HELLO)
            var ans = readln()
            while(ans != "1" && ans != "2" && ans != "3") {
                println("Вводимые данные должны быть целым числом от 1 до 3")
                ans = readln()
            }
            if (ans == "1") {
                authorize()
            }
            if (ans == "2") {
                register()
            }
            if (ans == "3") {
                return
            }
        }
    }

    private fun authorize() {
        switchState(States.AUTHORIZATION)
        currentUser = authorizationSystem.authorize()
        if (currentUser.checkLogin("0")) {
            return
        }
        if (currentUser.isAdmin()){
            adminSelection()
            return
        }
        selection()
        return
    }

    private fun register() {
        switchState(States.REGISTER)
        authorizationSystem.registerGeneralUser()
    }

    private fun selection() {
        while (true) {
            switchState(States.SELECTION)
            var ans = readln()
            while(ans != "0" && ans != "1") {
                println("Вводимые данные должны быть целым числом от 0 до 1")
                ans = readln()
            }
            if (ans == "0") {
                return
            }
            ordering()
        }
    }

    private fun adminSelection() {
        while (true) {
            switchState(States.ADMINSELECTION)
            var ans = readln()
            while(ans != "0" && ans != "1" && ans != "2") {
                println("Вводимые данные должны быть целым числом от 0 до 2")
                ans = readln()
            }
            if (ans == "0") {
                return
            }
            if (ans == "1") {
                ordering()
            }
            if (ans == "2") {
                editing()
            }
        }
    }

    private fun ordering() {
        menu.printMenu()
        val order = Order()
        val bool = buying(order)
        if (bool) {
            currentUser.lastOrder = order
            ordered()
            return
        }
        currentUser.lastOrder = order
        return
    }

    private fun buying(order: Order) : Boolean {
        while (true) {
            switchState(States.ORDERING)
            println("Для заказа доступно ${currentUser.getMoney()} рублей")
            val dish = getDish()
            if (dish.cookingTime == -1) {
                currentUser.lastOrder = order
                ordered()
                return false
            }
            println("Вы хотите заказать блюдо или посмотреть отзывы?")
            println("0. Завершить заказ")
            println("1. Заказать")
            println("2. Посмотреть отзывы")
            var number = readln()
            while (number != "0" && number != "1" && number != "2") {
                println("Необходимо выбрать 0, 1 или 2")
                number = readln()
            }
            if (number == "0") {
                return true
            }
            if (number == "1") {
                while (true) {
                    print("Введите количество порций: ")
                    try {
                        val dishCount = readln().toInt()
                        if (dishCount > 0) {
                            currentUser.buy(dish, dishCount, order)
                            break
                        }
                        else {
                            print("Нужно ввести положительное число: ")
                        }
                    }
                    catch (_: Exception) {
                        print("Нужно ввести целое число порций: ")
                    }
                }
            }
            if (number == "2") {
                dish.printReviews()
            }
        }
    }

    private fun editing() {
        while (true) {
            switchState(States.ADMINEDITING)
            var ans = readln()
            while(ans != "0" && ans != "1" && ans != "2") {
                println("Вводимые данные должны быть целым числом от 0 до 2")
                ans = readln()
            }
            if (ans == "1") {
                editMenu()
            }
            if (ans == "2") {
                editDish()
            }
            if (ans == "0") {
                return
            }
        }
    }

    private fun ordered() {
        while (true) {
            switchState(States.ORDERED)
            var ans = readln()
            while(ans != "0" && ans != "1" && ans != "2") {
                println("Вводимые данные должны быть целым числом от 0 до 2")
                ans = readln()
            }
            if (ans == "1") {
                canceling()
            }
            if (ans == "2") {
                review()
                return
            }
            if (ans == "0") {
                return
            }
        }
    }

    private fun editMenu() {
        switchState(States.ADMINEDITMENU)
        print("Введите название блюда: ")
        val dishName = readln()
        print("Введите описание блюда: ")
        val dishDescription = readln()
        print("Введите цену блюда (в рублях): ")
        val price = getPrice()
        print("Введите количество порций, доступных для заказа: ")
        val count = getPortions()
        print("Введите время приготовления в секундах: ")
        val time = getTime()
        menu.addDish(Dish(time, count, price, dishName, dishDescription))
        println("Блюдо успещно добавлено!")
    }

    private fun getTime() : Int {
        var timeString: String
        while (true) {
            timeString = readln()
            try{
                val time = timeString.toInt()
                if (time > 0) {
                    return time
                }
                else {
                    print("Время приготовления должно быть больше 0: ")
                }
            }
            catch (_: Exception) {
                print("Введите целое положительное количество секунд: ")
            }
        }
    }

    private fun getPortions() : Int {
        var countString: String
        while (true) {
            countString = readln()
            try{
                val count = countString.toInt()
                if (count >= 0) {
                    return count
                }
                else {
                    print("Количество не может быть отрицательным: ")
                }
            }
            catch (_: Exception) {
                print("Введите целое количество порций, не меньшее 0: ")
            }
        }
    }

    private fun getPrice() : Int {
        var priceString: String
        while (true) {
            priceString = readln()
            try{
                val price = priceString.toInt()
                if (price >= 0) {
                    return price
                }
                else {
                    print("Цена не может быть отрицательной: ")
                }
            }
            catch (_: Exception) {
                print("Введите неотрицательное целое число рублей: ")
            }
        }
    }

    private fun getDish() : Dish {
        while (true) {
            print("Введите номер блюда или 0, если хотите закончить: ")
            val stringNumber = readln()
            if (stringNumber == "0") {
                return Dish(-1, -1,10000, "", "")
            }
            try {
                val number = stringNumber.toInt()
                return menu.dishes[number - 1]
            }
            catch(_: Exception) {
                println("Введите номер блюда, соответствующий меню")
            }
        }
    }

    private fun editDish() {
        switchState(States.ADMINEDITDISH)
        menu.printMenu()
        val dish = getDish()
        if (dish.cookingTime == -1) {
            return
        }
        while (true) {
            println("Что нужно отредактировать?")
            println("0. Вернуться назад")
            println("1. Название блюда")
            println("2. Описание блюда")
            println("3. Количество порций, доступных для заказа")
            println("4. Время приготовление")
            println("5. Цена порции блюда")
            var ans = readln()
            while (ans != "0" && ans != "1" && ans != "2" && ans != "3" && ans != "4" && ans != "5") {
                print("Нужно ввести целое число от 0 до 5: ")
                ans = readln()
            }
            if (ans == "0") {
                return
            }
            if (ans == "1") {
                print("Введите новое название блюда: ")
                dish.dishName = readln()
            }
            if (ans == "2") {
                print("Введите новое описание блюда: ")
                dish.dishDescription = readln()
            }
            if (ans == "3") {
                print("Введите новое количество порций блюда, доступных для заказа: ")
                dish.count = getPortions()
            }
            if (ans == "4") {
                print("Введите время приготовления (в секундах): ")
                dish.cookingTime = getTime()
            }
            if (ans == "5") {
                print("Введите новую цену порции блюда (в рублях): ")
                dish.price = getPrice()
            }
        }
    }

    private fun canceling() {
        switchState(States.CANCELING)
        var ans = readln()
        while(ans != "0" && ans != "1") {
            println("Вводимые данные должны быть целым числом от 0 до 1")
            ans = readln()
        }
        if (ans == "0"){
            return
        }
        if (currentUser.lastOrder.isEmpty()) {
            println("Ваш последний заказ пуст, вы ничего не заказали, поэтому отменить его нельзя")
            return
        }
        else {
            currentUser.lastOrder.cancel(currentUser)
            return
        }
    }

    private fun review() {
        if (currentUser.lastOrder.isEmpty()) {
            println("Ваш последний заказ был пуст, поэтому вы не можете оставить отзыв")
            return
        }
        if (currentUser.lastOrder.reviewed) {
            println("Вы уже написали отзыв. После каждого заказа можно написать не более одного отзыва")
            return
        }
        switchState(States.REVIEW)
        menu.printMenu()
        writeReview()
        return
    }

    private fun writeReview() {
        while (true) {
            try {
                print("Введите номер блюда: ")
                var number = readln()
                val dishNumber = number.toInt()
                val dish = menu.dishes[dishNumber - 1]
                println("Поставьте оценку от 1 до 10: ")
                number = readln()
                val score = number.toInt()
                println("Напишите отзыв: ")
                val comment = readln()
                dish.addReview(Review(score, comment))
                println("Спасибо за ваш отзыв! Мы становимся лучше с каждым днём")
                currentUser.lastOrder.reviewed = true
                break
            }
            catch (_: Exception) {
                println("Введите корректное значение")
            }
        }
    }
}