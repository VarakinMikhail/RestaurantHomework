import kotlinx.serialization.Serializable

@Serializable
class Menu {
    var dishes: MutableList<Dish> = mutableListOf()

    fun addDish(dish: Dish) {
        dishes.add(dish)
    }

    fun printMenu() {
        println("Меню")
        var c = 1
        for (dish in dishes) {
            print("$c. ")
            dish.printDish()
            println()
            c += 1
        }
    }
}