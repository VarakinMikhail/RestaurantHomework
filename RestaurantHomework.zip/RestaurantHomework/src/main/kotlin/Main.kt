import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.lang.Exception

fun main(args: Array<String>) {
    val authorizationSystem = AuthorizationSystem()
    val menu = Menu()
    var state = State(authorizationSystem, menu)

    try { //Если есть сохраненные данные, то загрузим их
        state = Json.decodeFromString<State>(getText("state.json"))
        state.current = States.HELLO
        state.currentUser = GeneralUser(AuthorizationData("", ".", false), 0)
    }
    catch (_: Exception) { } //Иначе это новый ресторан (пользователя уведомлять об этом не нужно)

    state.hello()


    val json = Json.encodeToString(state)
    writeText("state.json", json)
}

fun getText(fileName: String) : String {
    var result = ""
    FileInputStream(fileName).use { fin ->
        var i: Int
        while (fin.read().also { i = it } != -1) {
            result += i.toChar()
        }
    }
    return result
}

fun writeText(fileName: String, json: String) {
    try {
        FileOutputStream(fileName).use { fos ->
            val buffer = json.toByteArray()
            fos.write(buffer, 0, buffer.size)
        }
    } catch (ex: IOException) {
        println(ex.message)
    }
}