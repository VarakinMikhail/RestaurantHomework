import kotlinx.serialization.Serializable

@Serializable
data class AuthorizationData(val login: String,
                        val hash: String,
                        val isAdmin: Boolean) {
}