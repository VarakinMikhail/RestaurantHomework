import kotlinx.serialization.Serializable
import java.lang.Exception

@Serializable
open class GeneralUser(private val authorizationData: AuthorizationData,
                       private var money: Int) {
    var lastOrder = Order()

    fun checkAuthorization(data: AuthorizationData) : Boolean {
        return data == authorizationData
    }

    fun checkLogin(string: String) : Boolean {
        return string == authorizationData.login
    }

    fun checkPassword(string: String) : Boolean {
        return  string == authorizationData.hash
    }

    fun isAdmin() : Boolean {
        return authorizationData.isAdmin
    }

    fun getMoney() : Int {
        return money
    }

    fun buy(dish: Dish, dishNumber: Int, order: Order) : Boolean {
        if (dishNumber <= dish.count && money >= dish.price * dishNumber) {
            money -= dish.price * dishNumber
            order.add(Pair(dish, dishNumber))
            return true
        }
        else if (dishNumber > dish.count) {
            println("Такое количество блюд недоступно")
        }
        else if (money <  dish.price * dishNumber) {
            println("На вашем счете недостаточно средств для совершения покупки")
        }
        return false
    }

    fun back(dish: Dish, dishNumber: Int) {
        money += dish.price * dishNumber
    }
}