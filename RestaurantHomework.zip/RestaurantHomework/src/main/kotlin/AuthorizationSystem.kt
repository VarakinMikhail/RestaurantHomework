import kotlinx.serialization.Serializable
import java.lang.Exception
import java.security.MessageDigest

@Serializable
class AuthorizationSystem {
    private var users: MutableList<GeneralUser> = mutableListOf()

    private fun getHash(password: String) : String {
        val bytes = MessageDigest.getInstance("MD5").digest(password.toByteArray())
        return with(StringBuilder()) {
            bytes.forEach { x -> append(String.format("%02X", x)) }
            toString().lowercase()
        }
    }

    fun authorize() : GeneralUser {
        while (true) {
            print("Введите логин или 0, если хотите выйти: ")
            val login = readln()
            if (login == "0") {
                return GeneralUser(AuthorizationData("0", "0", false), 0)
            }
            print("Введите пароль: ")
            val password = readln()
            val authorizationData1 = AuthorizationData(login, getHash(password), true)
            val authorizationData2 = AuthorizationData(login, getHash(password), false)
            for (i in users) {
                if (i.checkAuthorization(authorizationData1) || i.checkAuthorization(authorizationData2)) {
                    return i
                }
            }
            println("Неверный логин или пароль. Попробуйте снова")
        }
    }

    fun registerGeneralUser() {
        println("Вы хотите зарегистрироваться как посетитель или администратор?")
        println("1. Посетитель")
        println("2. Администратор")
        var choice = ""
        while (choice != "1" && choice != "2") {
            print("Необходимо выбрать 1 или 2: ")
            choice = readln()
            if (choice == "1") {
                return registerUser(false)
            }
            else if (choice == "2") {
                return registerUser(true)
            }
        }
        throw Exception()
    }

    private fun getPassword(): String {
        print("Придумайте пароль: ")
        return readln()
    }

    private fun getLogin() : String {
        print("Придумайте логин: ")
        var string = readln()
        while(containsLogin(string)){
            print("Этот логин уже занят. Придумайте другой: ")
            string = readln()
        }
        return string
    }

    private fun containsLogin(string: String) : Boolean {
        for (user in users) {
            if (user.checkLogin(string)) {
                return true
            }
        }
        return false
    }

    private fun getMoney() : Int {
        print("Введите количество денег, доступных для заказов в ресторане (в рублях): ")
        while (true){
            val string = readln()
            try {
                if (string.toInt() >= 0) {
                    return string.toInt()
                }
                else {
                    print("Введите неотрицательное число: ")
                }
            }
            catch (_: Exception) {
                print("Введите целое число: ")
            }
        }
    }

    private fun verifyCode() : Boolean {
        print("Введите специальный код для авторизации в качестве администратора: ")
        return getHash(readln()) == "dfa7d3811d0b2ba5ade016e7cc8b71f0"
    }

    private fun registerUser(isAdmin: Boolean) {
        val login = getLogin()
        val hash = getHash(getPassword())
        val money = getMoney()
        if (isAdmin && verifyCode()) {
            users.add(Administrator(AuthorizationData(login, hash, true), money))
        }
        else if (isAdmin) {
            println("Код неверный. Вы были зарегистрированы в качестве посетителя")
        }
        users.add(User(AuthorizationData(login, hash, false), money))
    }
}